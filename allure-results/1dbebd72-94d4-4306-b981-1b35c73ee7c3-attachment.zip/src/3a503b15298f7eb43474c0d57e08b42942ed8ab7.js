const { test, expect } = require('@playwright/test');

test('Double click example', async ({ page }) => {
    await page.goto('https://testkru.com/Elements/Buttons');

    await page.locator('#doubleClickBtn').dblclick();
});