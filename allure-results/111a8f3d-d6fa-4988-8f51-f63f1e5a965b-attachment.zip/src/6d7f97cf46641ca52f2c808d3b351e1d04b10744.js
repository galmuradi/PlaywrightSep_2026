
const { test, expect } = require('@playwright/test');

test('Drag and Drop functionality', async ({ page }) => {

    // Step 1: Open website
    await test.step('Open Droppable website', async () => {
        await page.goto('https://demoqa.com/droppable', {
            waitUntil: 'domcontentloaded'
        });
    });

    // Step 2: Locate source element
    const source = page.locator('#draggable').first();

    // Step 3: Locate destination element
    const target = page.getByRole('tabpanel', {
        name: 'Simple'
    }).locator('#droppable');

    // Step 4: Verify elements are visible
    await test.step('Verify drag and drop elements', async () => {
        await expect(source).toBeVisible();
        await expect(target).toBeVisible();
    });

    // Step 5: Perform drag and drop
    await test.step('Drag element into destination', async () => {
        await source.dragTo(target, {
            steps: 15
        });
    });

    // Step 6: Verify successful drop
    await test.step('Verify drop confirmation', async () => {
        await expect(target).toContainText('Dropped!');
    });

});