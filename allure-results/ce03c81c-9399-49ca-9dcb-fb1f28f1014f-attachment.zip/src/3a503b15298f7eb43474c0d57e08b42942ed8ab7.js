const { test, expect } = require('@playwright/test');

test('Double Click Button', async ({ page }) => {

    // Open website
    await page.goto('https://testkru.com/Elements/Buttons');

    // Locate the double-click button
    const doubleClickButton = page.locator('#doubleClickBtn');

    // Verify button is visible
    await expect(doubleClickButton).toBeVisible();

    // Perform double click
    await doubleClickButton.dblclick();

});