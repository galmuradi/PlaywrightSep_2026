const { test, expect } = require('@playwright/test');
test('Enter User Name', async ({ page }) => {
// Step 1: Open website
await test.step('Open website', async () => {
    await page.goto('https://testkru.com/Elements/TextFields', {
        waitUntil: 'domcontentloaded'
    });
});

// Step 2: Locate username field
const username = page.getByPlaceholder('First Name');

// Step 3: Enter user name
await test.step('Enter user name', async () => {
    await expect(username).toBeVisible();
    await username.pressSequentially('John Doe', { delay: 100 });
});
});
