const{test,expect}=require('@playwright/test');
test("This test different type of clicks",async({page})=>{
    await page.goto('http://localhost:5173/');
    await expect(page).toHaveTitle(/learnwithanimesh/);

    test.step("double click on the button using click method",async()=>{
        await page.getByText("Right Click Me").click({button:"right"});
    });
});