const { test, expect } = require('@playwright/test');

test('Double Click Button', async ({ page }) => {

// Step 1: Open website
test.step('Step one is to Open website', async () => {
await page.goto('https://testkru.com/Elements/Buttons');

// Step 2: Locate the button by text
const doubleClickButton = page.getByRole('button', {
    name: 'Double click on me'
});

// Step 3: Verify button is visible
await expect(doubleClickButton).toBeVisible();

// Step 4: Double click
await doubleClickButton.dblclick();

});
});