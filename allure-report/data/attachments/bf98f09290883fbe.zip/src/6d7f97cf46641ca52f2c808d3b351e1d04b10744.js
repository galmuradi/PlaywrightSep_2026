const { test, expect } = require('@playwright/test');

test('Drag and Drop Example', async ({ page }) => {

    await page.goto('https://testkru.com/Interactions/DragDrop');

    const source = page.locator('#drag1');
    const target = page.locator('#div1');

    await source.dragTo(target);

    await expect(target).toContainText('Draggable 1');
});