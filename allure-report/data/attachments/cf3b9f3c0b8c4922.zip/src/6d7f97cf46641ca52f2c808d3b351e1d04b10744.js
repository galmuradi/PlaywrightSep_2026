const { test, expect } = require('@playwright/test');

test('Drag and Drop', async ({ page }) => {

    await test.step('Open application', async () => {
        await page.goto('https://testkru.com/Interactions/DragDrop');
    });

    await test.step('Drag element to target', async () => {
        const source = page.locator('#drag1');
        const target = page.locator('#div1');

        await source.dragTo(target);
    });

    await test.step('Verify drop successful', async () => {
        await expect(page.locator('#div1')).toContainText('Draggable 1');
    });
});