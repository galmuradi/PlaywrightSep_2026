const { test, expect } = require('@playwright/test');

test('This test different type of clicks', async ({ page }) => {
    await page.goto('https://testkru.com/Elements/Buttons');

    await test.step('Double click on the button', async () => {
        await page.getByText('Double Click').dblclick();
    });
});