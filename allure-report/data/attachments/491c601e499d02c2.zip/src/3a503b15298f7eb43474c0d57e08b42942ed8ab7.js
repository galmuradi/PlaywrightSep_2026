const{test,expect}=require('@playwright/test');
test("This test different type of clicks",async({page})=>{
    await page.goto('https://testkru.com/Elements/Buttons');
    //await expect(page).toHaveTitle(//);

    test.step("double click on the button using click method",async()=>{
        await page.getByText("doubleClick").click();
    });
});